`timescale 1ns / 1ps

module ROM (
    input [2:0] addr,
    output reg [7:0] dataOut
);
    // Initialize the ROM with predefined values

endmodule



module Bitwise_Manipulation_RAM (
    input mode,                     // 0 for write, 1 for read
    input [2:0] addr,               // RAM address
	 input [1:0] operation,          // Operation code (AND, OR, XOR, NAND)
    input [7:0] dataIn,             // Input data
    input [7:0] romData,            // Data from ROM used in operations
    input CLK,                      // Clock signal
	 output reg [7:0] dataOut        // Output data
);
	// Your code here

endmodule



module Combined_Memory_System (
    input mode,
    input [2:0] systemAddr,
    input [7:0] dataIn,
    input [1:0] operation,
	 input CLK,
    output [7:0] systemOutput
);
	// Your code here
	 
endmodule

